// E’lon qo‘shish funksiyasi
function addAdvert() {
    let advert = {
        name: document.getElementById("name").value,
        phone: document.getElementById("phone").value,
        from_location: document.getElementById("from_location").value,
        to_location: document.getElementById("to_location").value,
        car_type: document.getElementById("car_type").value,
        seats: document.getElementById("seats").value,
        price: document.getElementById("price").value,
        cargo: document.getElementById("cargo").value
    };

    fetch('/add_advert', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(advert)
    }).then(response => response.json()) {
        alert("E’lon qo‘shildi!");
        loadAdverts();
    };
    .catch(error =>
        console.error("xatoli:", error));
}

// E’lonlarni yuklash
function loadAdverts() {
    fetch('/get_adverts')
        .then(response => response.json())
        .then(data => {
            let advertsDiv = document.getElementById("adverts");
            advertsDiv.innerHTML = "";
            data.forEach(advert => {
                advertsDiv.innerHTML += 
                    <div class="advert-box">
                        <h3>${advert[1]}</h3>
                        <p>📍 ${advert[3]} → ${advert[4]}</p>
                        <p>🚗 Mashina turi: ${advert[5]}</p>
                        <p>💺 Joylar: ${advert[6]}</p>
                        <p>💰 Narx: ${advert[7]} so‘m</p>
                        <p>📦 Yuk: ${advert[8]}</p>
                        <p>📞 <a href="tel:${advert[2]}">${advert[2]}</a></p>
                    </div>
                ;
            });
        });
}

document.addEventListener("DOMContentLoaded", loadAdverts);