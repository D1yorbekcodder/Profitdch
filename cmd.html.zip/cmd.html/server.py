from flask import Flask, request, render_template, redirect
import sqlite3

app = Flask(__name__)

def create_db():
    conn = sqlite3.connect('ads.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT,
        driver_name TEXT,
        car_type TEXT,
        from_location TEXT,
        to_location TEXT,
        seat_count INTEGER,
        price INTEGER,
        phone TEXT,
        takes_cargo TEXT
    )''')
    conn.commit()
    conn.close()

create_db()

@app.route('/')
def home():
    conn = sqlite3.connect('ads.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ads")
    ads = cursor.fetchall()
    conn.close()
    
    return render_template("index.html", ads=[{
        "id": ad[0], "type": ad[1], "driver_name": ad[2],
        "car_type": ad[3], "from_location": ad[4], "to_location": ad[5],
        "seat_count": ad[6], "price": ad[7], "phone": ad[8], "takes_cargo": ad[9]
    } for ad in ads])

@app.route('/add_advert', methods=['POST'])
def add_advert():
    data = request.json
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO adverts (type, driver_name, car_type, from_location, to_location, seat_count, price, phone, takes_cargo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", 
                   ("Yo'lovchi", data["driver_name"], data["car_type"], data["from_location"], data["to_location"], data["seat_count"], data["price"], data["phone"], data["takes_cargo"]))
    conn.commit()
    conn.close()
    return jsonify({'message':'E`lon qo`shildi!'})

@app.route('/delete_ad/<int:id>', methods=['POST'])
def delete_ad(id):
    conn = sqlite3.connect('ads.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM ads WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)